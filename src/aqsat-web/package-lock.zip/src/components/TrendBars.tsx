import { money } from "../lib/persian";

export interface TrendBarPoint {
  label: string;
  value: number;
}

/** Dependency-free SVG bar chart (TailAdmin's thin-chart-wrapper idea, without pulling
 * ApexCharts into the bundle). Positive bars grow in mint from the zero line, negative ones
 * hang below it in ember — exactly what P&L by-month needs. Persian digits, tabular labels. */
export function TrendBars({ data, height = 180, title }: { data: TrendBarPoint[]; height?: number; title?: string }) {
  if (data.length === 0) {
    return <div className="p-6 text-center text-[12.5px] text-(--ice-3)">داده‌ای برای نمایش نیست.</div>;
  }

  const maxAbs = Math.max(...data.map((d) => Math.abs(d.value)), 1);
  const width = Math.max(data.length * 64, 320);
  const zeroY = height / 2;
  const barWidth = 34;
  const gap = (width - data.length * barWidth) / data.length;

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height + 34}`} width="100%" style={{ minWidth: width }} role="img" aria-label={title ?? "نمودار روند"}>
        <line x1={0} x2={width} y1={zeroY} y2={zeroY} className="stroke-(--edge-2)" strokeWidth={1} />
        {data.map((d, i) => {
          const barHeight = (Math.abs(d.value) / maxAbs) * ((height / 2) - 12);
          const x = i * (barWidth + gap) + gap / 2;
          const positive = d.value >= 0;
          return (
            <g key={`${d.label}-${i}`}>
              <title>{`${d.label}: ${money(d.value)}`}</title>
              <rect
                x={x}
                y={positive ? zeroY - barHeight : zeroY}
                width={barWidth}
                height={Math.max(barHeight, 1)}
                rx={5}
                className={positive ? "fill-(--mint)" : "fill-(--ember)"}
                opacity={0.88}
              />
              <text
                x={x + barWidth / 2}
                y={height + 14}
                textAnchor="middle"
                className="fill-(--ice-3) text-[10px]"
              >
                {d.label}
              </text>
              <text
                x={x + barWidth / 2}
                y={positive ? zeroY - barHeight - 5 : zeroY + barHeight + 12}
                textAnchor="middle"
                className="fill-(--ice-2) text-[9px] tabular-nums"
              >
                {money(d.value)}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
